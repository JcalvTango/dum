(function () {
    'use strict';
    var widgetFunction = function () {

        angular.module('sailpoint.home.desktop.app')
            .config(['$httpProvider', function ($httpProvider) {
                $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";
            }])


            .controller('AppRequestPluginWidgetCtrl', ['$scope', '$http', 'navigationService', function ($scope, $http, navigationService) {

                $scope.goToUrl = function (goToURL) {
                    //console.log("goToUrl: " + goToURL);

                    navigationService.go({
                        url: goToURL
                    });
                };

                $scope.AppType = "Application";

                var config = {
                    headers: {
                        'X-XSRF-TOKEN': PluginHelper.getCsrfToken()
                    }
                }, promises;

                //Calling that function when the search is needed
                $scope.search = function (event) {
                    //console.log("Starting search with filter: #" + this.applicationFilterInput+ "# and type: #" + this.AppType + "#");
                    //console.log(event);
                    //console.log(this.AppType);
                    if (event == null || event.key == "Enter") {
                        //console.log("A search has been requested.");
                        config.params = {};
                        config.params.filter = this.applicationFilterInput;
                        if (this.AppType != null && this.AppType != '--') {
                            $http.get(PluginHelper.getPluginRestUrl('iiqpluginapplicationrequest/searchByType/' + encodeURIComponent(this.AppType) + "/"), config).then(function (response) {
                                //console.log("Got a response for search by type");
                                //console.log(response);
                                $scope.applications = response.data;
                            });
                        } else {
                            $http.get(PluginHelper.getPluginRestUrl('iiqpluginapplicationrequest/search'), config).then(function (response) {
                                //console.log("Got a response for search");
                                //console.log(response);
                                $scope.applications = response.data;
                            });
                        }
                    } else {
                        //console.log("No search tiggered...")
                    }
                };

                //Getting applications
                $scope.search(null);

            }]) // End controller


            .directive('spAppRequestWidget', function () {
                return {
                    restrict: 'E',
                    controller: 'AppRequestPluginWidgetCtrl',
                    templateUrl: PluginHelper.getPluginFileUrl('iiqpluginapplicationrequest', 'ui/html/AppRequestWidgetTemplate.html')
                };


            }); // End directive

    }; // End widgetFunction

    // Adds widgetFunction to IdentityIQ
    PluginHelper.addWidgetFunction(widgetFunction);

})(); 

