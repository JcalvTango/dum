/**
 * Create the module.
 */
var customObjMGModule = angular.module('CustomObjMG', [ 'ui.bootstrap' ]);

/**
 * Controller for the todo list.
 */
customObjMGModule.controller('CustomObjMGController', function(
		customObjMGService, $q, $uibModal, $scope) {

	var me = this;

	me.custObjName = undefined;

	/**
	 * @property Array The CustomObjs for a user.
	 */
	me.customObjs = [];

	me.selectedCustomObjs = [];

	/**
	 * Fetches the todos from the server.
	 * 
	 * @return Promise A promise that resolves with the array of todos.
	 */
	function fetchCustomObjs() {
		return customObjMGService.getCustomObjs();
	}

	/**
	 * Gets the todos from the server and sets them on the controller.
	 */
	me.getCustomObjs = function() {
		alert("set customobjs");
		// fetchCustomObjs().then(function(objects) {
		me.customObjs = customObjMGService.getCustomObjs();
		//me.customObjs = [ "applicationHealthPluginConfig",
			//"Sample Custom Object - Form" ];
		me.selectedCustomObjs = {
				"applicationHealthPluginConfig" : false,
				"Sample Custom Object - Form" : false
			};
		// });
	};

	/**
	 * Adds a new todo using the data entered by the user.
	 */
	me.searchObj = function() {
		me.customObjs = customObjMGService.searchCustomObj(me.name);
		me.selectedCustomObjs = {
			"applicationHealthPluginConfig" : false,
			"Sample Custom Object - Form" : false
		};
		alert("search:" + me.selectedCustomObjs);
	};

	me.deleteCustomObjs = function() {
		alert(me.selectedCustomObjs);
		me.customObjs = customObjMGService
				.deleteCustomObjs(me.selectedCustomObjs);
		// me.selectedCustomObjs={"applicationHealthPluginConfig": false,
		// "Sample Custom Object - Form": false};
	};

	/**
	 * Shows the flagged users modal dialog.
	 */
	me.viewFlaggedUsers = function() {
		$uibModal.open({
			animation : false,
			controller : 'FlaggedUsersCtrl as ctrl',
			templateUrl : PluginHelper.getPluginFileUrl('TodoPlugin',
					'ui/html/flagged-template.html')
		});
	};

});

/**
 * Service that handles functionality around todos.
 */
customObjMGModule.service('customObjMGService', function($http) {

	var config = {
		headers : {
			'X-XSRF-TOKEN' : PluginHelper.getCsrfToken()
		}
	};

	return {

		/**
		 * Gets todos for the logged in user.
		 * 
		 * @return Promise A promise that resolves with an array of todos.
		 */
		getCustomObjs : function() {
			var TODOS_URL = PluginHelper
					.getPluginRestUrl('CustomObjMGPlugin/customObjs');
			return $http.get(TODOS_URL, config).then(function(response) {
                return response.data.objects;
            });;
		},

		/**
		 * Gets todos for the logged in user.
		 * 
		 * @return Promise A promise that resolves with an array of todos.
		 */
		searchCustomObj : function() {
			var TODOS_URL = PluginHelper.getPluginRestUrl('TodoPlugin/todos');

			var customObjects = [ "applicationHealthPluginConfig",
					"Sample Custom Object - Form" ];

			/*
			 * return $http.get(TODOS_URL, config).then(function(response) {
			 * return response.data.objects; });
			 */
			return customObjects;
		},
		/**
		 * Gets todos for the logged in user.
		 * 
		 * @return Promise A promise that resolves with an array of todos.
		 */
		deleteCustomObjs : function(selectedCustomObjs) {
			var TODOS_URL = PluginHelper.getPluginRestUrl('TodoPlugin/todos');

			var customObjects = [];
			angular.forEach(selectedCustomObjs, function(value, key) {
				// SHOW THE EXTRACTED DATA.
				console.log(key + ":****************** " + value + ": " + key);
				if (!value) {
					customObjects.push(key);
					console.log("Check if truee" + key);
				}
			});

			/*
			 * return $http.get(TODOS_URL, config).then(function(response) {
			 * return response.data.objects; });
			 */
			return customObjects;
		},

		/**
		 * Gets the specified todo.
		 * 
		 * @param string
		 *            The todo id.
		 * @return Promise A promise that resolves with a todo.
		 */
		getTodo : function(id) {
			var TODO_URL = PluginHelper.getPluginRestUrl('TodoPlugin/todos/'
					+ id);

			return $http.get(TODO_URL, config).then(function(response) {
				return response.data;
			});
		}
	};

});

/**
 * Services that handles functionality around the page configuration.
 */
customObjMGModule.service('pageConfigService', function($http) {

	var config = {
		headers : {
			'X-XSRF-TOKEN' : PluginHelper.getCsrfToken()
		}
	};

	return {

		/**
		 * Gets the page configuration.
		 * 
		 * @return Promise A promise resolving with a page configuration object.
		 */
		getPageConfig : function() {
			var PAGE_CONFIG_URL = PluginHelper
					.getPluginRestUrl('TodoPlugin/pageConfig');

			return $http.get(PAGE_CONFIG_URL, config).then(function(response) {
				return response.data;
			});
		}

	};

});
