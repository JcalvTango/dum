var app = angular.module('ManageCustomObject',
		[ 'angularUtils.directives.dirPagination','ngAnimate', 'ngSanitize', 'ngMessages', 'ui.bootstrap','json-tree','prettyXml' ]);
app.config(function ($httpProvider) {  
	  $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";  
	}); 

/**
 * Service that handles functionality.
 */
app.service('customObjMGService', function($http) {

	var config = {
		headers : {
			'X-XSRF-TOKEN' : PluginHelper.getCsrfToken()
		}
	};
	return {

		/**
		 *  Get all Custom objects.
		 *  
		 * @return
		 */
		getCustomObjs : function() {
			
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/customObjs');
			
			return $http.get(ManageCustomObject_URL, config).then(function(response) {

				var log = [];
				angular.forEach(response.data, function(value, key) {
					var map = {
						"id" : key+1,
						"customObject_name" : value.cust_name,
						"cust_id" : value.cust_id
					};
					this.push(map);
				}, log);
				return log;
			});
		},
		/**
		 * Delete the selected Custom objects.
		 * 
		 * @return
		 */
		deleteCustomObjs : function(selectedNames) {
			
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/deleteCustomObjs');
			return $http.delete(ManageCustomObject_URL+"/"+selectedNames).then(function(response) {
				return true;
			});
		},
		/**
		 * Search the Custom objects.
		 * 
		 * @return
		 */
		searchCustomObjs : function(searchString) {
			
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/searchCustomObjs');
			var data = {
                names: searchString
            };
			
			return $http.post(ManageCustomObject_URL, data,config).then(function(response) {
				var log = [];
				angular.forEach(response.data, function(value, key) {
					var map = {
						"id" : key+1,
						"customObject_name" : value.cust_name,
						"cust_id" : value.cust_id
					};
					this.push(map);
				}, log);
				return log;
			});
		},
		/**
		 * Get the Custom object Information.
		 * 
		 * @return
		 */
		getCustomObjectAttrs : function(customName) {
			
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/getCustomObjectAttrs');
			var data = {
					customName: customName
            };
			
			return $http.post(ManageCustomObject_URL, data,config).then(function(response) {
				return response.data;
			});
		},
		/**
		 * Get the Custom object XML.
		 * 
		 * @return
		 */
		getXMLCustomObject : function(customName) {
			
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/getXMLCustomObject');
			var data = {
					customName: customName
            };
			
			return $http.post(ManageCustomObject_URL, data,config).then(function(response) {
				return response.data;
			});
		},
		/**
		 * Save the Custom object Information.
		 * 
		 * @return
		 */
		saveCustomObject : function(customObjAttributes,customObjectName,customObjectOperation) {
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/saveCustomObject');
			var data = {
					customObjAttrs: customObjAttributes,
					customObjectName: customObjectName,
					customObjectOperation: customObjectOperation
            };
			return $http.post(ManageCustomObject_URL, data,config).then(function(response) {
				return response.data;
			});
		},
		/**
		 * Get message.
		 * 
		 * @return
		 */
		getMessage : function(messageKey) {
			var ManageCustomObject_URL = PluginHelper
					.getPluginRestUrl('ManageCustomObjectPlugin/getMessage');
			var data = {
					messageKey: messageKey
            };
			return $http.post(ManageCustomObject_URL, data,config).then(function(response) {
				return response.data;
			});
		},
	};

});



app.controller('manageCustomObjectCtrl', function (customObjMGService,$scope,$uibModal,$location,$log, $document,$http, $q,$rootScope) {
	
	$scope.users=[];
	$scope.selectedCustomObjs = {};
	
	$rootScope.alerts = [];
	
	$scope.searchString="";
	
	function fetchCustomObjects() {
		return customObjMGService.getCustomObjs();
	}
	
	$scope.searchCustomObjs = function(searchString) {				
		var finalUsers=[];
		finalUsers = customObjMGService.searchCustomObjs(searchString);				
		finalUsers.then(function(data) {
	        $scope.users = data;
	    })
	};					

	promises = {
		customObjects : fetchCustomObjects()
	};

	// load the page config and the custom objects
	$q.all(promises).then(function(result) {
		$scope.users = result.customObjects;
	});

	$scope.sort = function(keyname) {
		$scope.sortKey = keyname; // set the sortKey to the param
		$scope.reverse = !$scope.reverse; // if true make it false and
	}
	
	  var $ctrl = this;
	  $ctrl.items = [];
	 
	  
	  $ctrl.animationsEnabled = true;
	  $ctrl.editobject=function() {
		  $ctrl.open();
	  };
	  
	  $scope.closeAlert = function(index) {
		    $scope.alerts.splice(index, 1);
	  };
	  	  
	  $scope.deleteObjs = function (selectedCustomObjs,size, parentSelector) {
		  
		var selectedObjStr='';
		
		angular.forEach($scope.users, function(value, key) {
			var selectedObj=selectedCustomObjs[value.customObject_name ];
			
			if(selectedObj != undefined && selectedObj){
				selectedObjStr+=value.customObject_name+",";
			}
		});
		// check if atleast one object name is selected
		if(selectedObjStr !=''){
		    var parentElem = parentSelector ? 
		    angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
		    var modalInstance = $uibModal.open({
		      animation: $ctrl.animationsEnabled,
		      ariaLabelledBy: 'modal-title',
		      ariaDescribedBy: 'modal-body',
		      templateUrl: 'myModalContentDelete.html',
		      controller: 'ModalInstanceCtrl',
		      controllerAs: '$ctrl',
		      size: size,
		      appendTo: parentElem,
		      resolve: {
		        items: function () {
		          return $ctrl.items;
		        },
		        customName:function () {
		          return selectedObjStr;
		        },operation:function () {	         
		          return "delete";
		        }
		      }
		    });
		    
		    modalInstance.result.then(function (selectedItem) {
			      $ctrl.selected = selectedItem;
		          $scope.users =[];
		          
			      var finalUsers = customObjMGService.getCustomObjs();
					finalUsers.then(function(data) {
						$scope.selectedCustomObjs = {};
				        $scope.users = data;
				       if(!$scope.msgDeleteSuccessful){
							 var message = customObjMGService.getMessage('ManageCustomObjectPlugin_CustomObject_DELETE_SUCCESSFUL');
							 message.then(function(data) {
								 $scope.msgDeleteSuccessful = data;
								 $scope.alerts.push({ type: 'success', msg: $scope.msgDeleteSuccessful });
							    });
						 } else{
							$scope.alerts.push({ type: 'success', msg: $scope.msgDeleteSuccessful }); 
						 }
				    });
			    }, function () {
			      //$log.info('Modal dismissed at: ' + new Date());
			    });
		}else{
			 //$log.info('Nothing to delete');
			 //$log.info($scope.msgDeleteRequiredObject);
			 if(!$scope.msgDeleteRequiredObject){
				 var message = customObjMGService.getMessage('ManageCustomObjectPlugin_CustomObject_DELETE_OBJECTREQUIRED');
				 message.then(function(data) {
					 $scope.msgDeleteRequiredObject = data;
					 $scope.alerts.push({ type: 'danger', msg: $scope.msgDeleteRequiredObject });
				    });
			 } else{
				$scope.alerts.push({ type: 'danger', msg: $scope.msgDeleteRequiredObject }); 
			 }
			 
		}
	  };
	  
	  $scope.openXML = function (customObjectName,size, parentSelector) {
		  $scope.customName=customObjectName;
		  
	    var parentElem = parentSelector ? 
	    angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
	    var modalInstance = $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      ariaLabelledBy: 'modal-title',
	      ariaDescribedBy: 'modal-body',
	      templateUrl: 'myModalContentXML.html',
	      controller: 'ModalInstanceCtrl',
	      controllerAs: '$ctrl',
	      size: size,
	      appendTo: parentElem,
	      resolve: {
	        items: function () {
	          return $ctrl.items;
	        },
	        customName:function () {
	          return customObjectName;
	        },operation:function () {	         
	          return "xml";
	        }
	      }
	    });

	    modalInstance.result.then(function (selectedItem) {
	      $ctrl.selected = selectedItem;
	    }, function () {
	      //$log.info('Modal dismissed at: ' + new Date());
	    });
	  };

	  $scope.open = function (customObjectName,size, parentSelector) {
		  $scope.customName=customObjectName;
		  
	    var parentElem = parentSelector ? 
	    angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
	    var modalInstance = $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      ariaLabelledBy: 'modal-title',
	      ariaDescribedBy: 'modal-body',
	      templateUrl: 'myModalContent.html',
	      controller: 'ModalInstanceCtrl',
	      controllerAs: '$ctrl',
	      size: size,
	      appendTo: parentElem,
	      resolve: {
	        items: function () {
	          return $ctrl.items;
	        },
	        customName:function () {
	          return customObjectName;
	        },operation:function () {
	          $scope.showText=false;
	          return "edit";
	        }
	      }
	    });

	    modalInstance.result.then(function (selectedItem) {
	      $ctrl.selected = selectedItem;
	      if(!$scope.msgUpdateSuccessful){
				 var message = customObjMGService.getMessage('ManageCustomObjectPlugin_CustomObject_UPDATE_SUCCESSFUL');
				 message.then(function(data) {
					 $scope.msgUpdateSuccessful = data;
					 $scope.alerts.push({ type: 'success', msg: $scope.msgUpdateSuccessful });
				    });
			 } else{
				$scope.alerts.push({ type: 'success', msg: $scope.msgUpdateSuccessful }); 
			 }
	    }, function () {
	      //$log.info('Modal dismissed at: ' + new Date());
	    });
	  };
	  
	  $scope.create = function (size, parentSelector) {
		  
		  var customObjectName=undefined;
		  $scope.showText=true;
	    var parentElem = parentSelector ? 
	      angular.element($document[0].querySelector('.modal-demo ' + parentSelector)) : undefined;
	    var modalInstance = $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      ariaLabelledBy: 'modal-title',
	      ariaDescribedBy: 'modal-body',
	      templateUrl: 'myModalContent.html',
	      controller: 'ModalInstanceCtrl',
	      controllerAs: '$ctrl',
	      size: size,
	      appendTo: parentElem,
	      resolve: {
	        items: function () {
	          return $ctrl.items;
	        },
	        customName:function () {
	          return customObjectName;
	        },operation:function () {
	          return "Create";
	        }
	      }
	    });

	    modalInstance.result.then(function (selectedItem) {
	      $ctrl.selected = selectedItem;
	     
	      $scope.users =[];
	      
          var finalUsers = customObjMGService.getCustomObjs();
			finalUsers.then(function(data) {
				$scope.selectedCustomObjs = {};
		        $scope.users = data;		        
		        if(!$scope.msgCreateSuccessful){
					 var message = customObjMGService.getMessage('ManageCustomObjectPlugin_CustomObject_CREATE_SUCCESSFUL');
					 message.then(function(data) {
						 $scope.msgCreateSuccessful = data;
						 $scope.alerts.push({ type: 'success', msg: $scope.msgCreateSuccessful + ' ' + selectedItem + '!' });
					    });
				 } else{
					$scope.alerts.push({ type: 'success', msg: $scope.msgCreateSuccessful + ' ' + selectedItem + '!'}); 
				 }
		    });
	    }, function () {
	      //$log.info('Modal dismissed111 at: ' + new Date());
	    });
	  };

	  $scope.openComponentModal = function () {
	    var modalInstance = $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      component: 'modalComponent',
	      resolve: {
	        items: function () {
	          return $ctrl.items;
	        }
	      }
	    });

	    modalInstance.result.then(function (selectedItem) {
	      $ctrl.selected = selectedItem;
	    }, function () {
	      //$log.info('modal-component dismissed at: ' + new Date());
	    });
	  };

	  $scope.openMultipleModals = function () {
	    $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      ariaLabelledBy: 'modal-title-bottom',
	      ariaDescribedBy: 'modal-body-bottom',
	      templateUrl: 'stackedModal.html',
	      size: 'sm',
	      controller: function($scope) {
	        $scope.name = 'bottom';  
	      }
	    });

	    $uibModal.open({
	      animation: $ctrl.animationsEnabled,
	      ariaLabelledBy: 'modal-title-top',
	      ariaDescribedBy: 'modal-body-top',
	      templateUrl: 'stackedModal.html',
	      size: 'sm',
	      controller: function($scope) {
	        $scope.name = 'top';  
	      }
	    });
	  };

	  $scope.toggleAnimation = function () {
	    $ctrl.animationsEnabled = !$ctrl.animationsEnabled;
	  };
	});

	// Please note that $uibModalInstance represents a modal window (instance)
	// dependency.
	// It is not the same as the $uibModal service used above.

	app.controller('ModalInstanceCtrl', function ($uibModalInstance,$scope,$document,$window,$log,customObjMGService, items,customName,operation) {
		
		$scope.users=[];
		$scope.selectedCustomObjs = {};
		$scope.alerts = [];
		$scope.jsonData = defaultData();
		$scope.customName=customName;
		$scope.operation="Edit -";
		if(operation == 'edit'){
			$scope.showText=true;
		}else{
			$scope.showText=false;
			$scope.operation="Create";
		}
		$scope.xml='';
		
		if(operation == 'edit'){
			var response = customObjMGService.getCustomObjectAttrs(customName);
			response.then(function(data) {
				$scope.jsonData = data;
			})
		}if(operation == 'xml'){
			var response = customObjMGService.getXMLCustomObject(customName);
			response.then(function(data) {
				$scope.xml = data;
			})
		}
	     
	      $scope.refresh = function(){
	    	  if($scope.operation == "Create"){
	    		  $scope.jsonData = {};
	    	  } else{
	    		  var response = customObjMGService.getCustomObjectAttrs($scope.customName);
					response.then(function(data) {
						$scope.jsonData = data;
					})
	    	  }
	    	  
	      }
	      
	      function parse(data){
	          return data ? JSON.parse(data) : {};
	      };
	
	      function defaultData() {	    	  
	          return {};
	      };
	      
	  var $ctrl = this;
	  $ctrl.items = items;
	  $ctrl.selected = {
	    item: $ctrl.items[0]
	  };
	  
	  $ctrl.deleteObject = function () {
		  var response=customObjMGService.deleteCustomObjs(customName);
		  $scope.selectedCustomObjs = {};
		  $scope.users = [];
		  response.then(function(response){
			 $uibModalInstance.close($ctrl.selected.item);
		  });
	  }

	  $ctrl.saveObject = function () {		  
		  //$log.info('Save object: ' + $scope.jsonData + " name "+ $scope.customName + " operation: " + $scope.operation);
		  var response=customObjMGService.saveCustomObject($scope.jsonData,$scope.customName,$scope.operation);
		  $scope.selectedCustomObjs = {};
		  $scope.users = [];
		  response.then(function(response){
			$uibModalInstance.close($scope.customName);
		  }, function(response) {
			    $scope.errorMsg = response.data;
		  });
	  };

	  $ctrl.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	  };
	});

	// Please note that the close and dismiss bindings are from
	// $uibModalInstance.

	app.component('modalComponent', {
	  templateUrl: 'myModalContent.html',
	  bindings: {
	    resolve: '<',
	    close: '&',
	    dismiss: '&'
	  },
	  controller: function () {
	    var $ctrl = this;

	    $ctrl.$onInit = function () {
	      $ctrl.items = $ctrl.resolve.items;
	      $ctrl.selected = {
	        item: $ctrl.items[0]
	      };
	    };

	    $ctrl.saveObject = function () {
	      $ctrl.close({$value: $ctrl.selected.item});
	    };

	    $ctrl.cancel = function () {
	      $ctrl.dismiss({$value: 'cancel'});
	    };
	  }
	});